# ============================================
# Expo Build Fix - Simple PowerShell Script
# Copy-paste this entire script into PowerShell
# ============================================

Write-Host "`n=== Expo Android Build Fix ===" -ForegroundColor Cyan

# 1. Move to project directory
Write-Host "`n[1] Moving to project directory..." -ForegroundColor Yellow
cd D:\JS
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Cannot access D:\JS" -ForegroundColor Red
    exit 1
}
Write-Host "✓ In D:\JS" -ForegroundColor Green

# 2. Create assets directory
Write-Host "`n[2] Creating assets directory..." -ForegroundColor Yellow
if (-not (Test-Path "assets")) {
    New-Item -ItemType Directory -Path "assets" -Force | Out-Null
}
Write-Host "✓ assets directory ready" -ForegroundColor Green

# 3. Generate required images using Python
Write-Host "`n[3] Generating required images..." -ForegroundColor Yellow

$pythonCode = @"
from PIL import Image
import os

os.makedirs('assets', exist_ok=True)

# adaptive-icon.png (1024x1024)
Image.new('RGB', (1024, 1024), color=(66, 165, 245)).save('assets/adaptive-icon.png')
print('✓ Created adaptive-icon.png')

# splash.png (1080x2340)
Image.new('RGB', (1080, 2340), color=(66, 165, 245)).save('assets/splash.png')
print('✓ Created splash.png')

# icon.png (192x192)
Image.new('RGB', (192, 192), color=(66, 165, 245)).save('assets/icon.png')
print('✓ Created icon.png')
"@

try {
    if (Get-Command python -ErrorAction SilentlyContinue) {
        $pythonCode | python
    } elseif (Get-Command python3 -ErrorAction SilentlyContinue) {
        $pythonCode | python3
    } else {
        Write-Host "⚠ Python not found. Creating placeholder images..." -ForegroundColor Yellow
        # Create minimal valid PNG files
        [byte[]]$pngHeader = 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A
        
        $adaptiveIconPath = "assets\adaptive-icon.png"
        $splashPath = "assets\splash.png"
        $iconPath = "assets\icon.png"
        
        [System.IO.File]::WriteAllBytes($adaptiveIconPath, $pngHeader)
        [System.IO.File]::WriteAllBytes($splashPath, $pngHeader)
        [System.IO.File]::WriteAllBytes($iconPath, $pngHeader)
        
        Write-Host "⚠ Created placeholder PNG files (you may need real images)" -ForegroundColor Yellow
    }
} catch {
    Write-Host "ERROR: Failed to create images: $_" -ForegroundColor Red
    exit 1
}

# 4. Update app.json
Write-Host "`n[4] Updating app.json..." -ForegroundColor Yellow

if (-not (Test-Path "app.json")) {
    Write-Host "ERROR: app.json not found" -ForegroundColor Red
    exit 1
}

# Read current app.json
$appJsonContent = Get-Content "app.json" -Raw
$appJson = $appJsonContent | ConvertFrom-Json

# Ensure expo section exists
if (-not $appJson.expo) {
    $appJson | Add-Member -Name "expo" -Value @{} -MemberType NoteProperty -Force
}

# Add/update required fields
$appJson.expo | Add-Member -Name "icon" -Value "./assets/icon.png" -MemberType NoteProperty -Force
$appJson.expo | Add-Member -Name "splash" -Value @{
    "image" = "./assets/splash.png"
    "resizeMode" = "contain"
    "backgroundColor" = "#42A5F5"
} -MemberType NoteProperty -Force

# Ensure android section exists
if (-not $appJson.expo.android) {
    $appJson.expo | Add-Member -Name "android" -Value @{} -MemberType NoteProperty -Force
}

# Set android package if not set
if (-not $appJson.expo.android.package) {
    $appJson.expo.android.package = "com.example.mynewquiz"
}

# Add adaptive icon
$appJson.expo.android | Add-Member -Name "adaptiveIcon" -Value @{
    "foregroundImage" = "./assets/adaptive-icon.png"
    "backgroundColor" = "#42A5F5"
} -MemberType NoteProperty -Force

# Save updated app.json (with nice formatting)
$appJsonContent = $appJson | ConvertTo-Json -Depth 10
Set-Content "app.json" -Value $appJsonContent
Write-Host "✓ app.json updated" -ForegroundColor Green

# 5. Clean old builds
Write-Host "`n[5] Cleaning old build artifacts..." -ForegroundColor Yellow

$directoriestoDelete = @("android", "build")
foreach ($dir in $directoriestoDelete) {
    if (Test-Path $dir) {
        Remove-Item -Path $dir -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "✓ Removed $dir" -ForegroundColor Green
    }
}

# 6. Clear npm cache
Write-Host "`n[6] Clearing npm cache..." -ForegroundColor Yellow
npm cache clean --force | Out-Null
Write-Host "✓ npm cache cleared" -ForegroundColor Green

# 7. Reinstall dependencies
Write-Host "`n[7] Reinstalling dependencies..." -ForegroundColor Yellow
npm install --legacy-peer-deps
if ($LASTEXITCODE -ne 0) {
    Write-Host "⚠ npm install had warnings, but continuing..." -ForegroundColor Yellow
}

# Summary
Write-Host "`n" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host "✓ FIX COMPLETE!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green

Write-Host "`n📋 Next steps:`n" -ForegroundColor Green

Write-Host "1️⃣  Test locally (optional but recommended):" -ForegroundColor Cyan
Write-Host "    npx expo prebuild --platform android --clean`n"

Write-Host "2️⃣  Build with EAS:" -ForegroundColor Cyan
Write-Host "    eas build --platform android --profile development`n"

Write-Host "3️⃣  If you still get image errors:" -ForegroundColor Cyan
Write-Host "    - Create proper PNG files and place in assets/ folder:" -ForegroundColor Cyan
Write-Host "    - adaptive-icon.png (1024x1024px)" -ForegroundColor Cyan
Write-Host "    - splash.png (1080x2340px)" -ForegroundColor Cyan
Write-Host "    - icon.png (192x192px)`n"

Write-Host "========================================" -ForegroundColor Green
Write-Host "`nDone! Ready to build. 🚀" -ForegroundColor Green
