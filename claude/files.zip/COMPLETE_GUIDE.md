# Expo Android Build - 完全ガイド

## 📊 実行フロー

```
┌─────────────────────────────────┐
│  START: ビルド修正が必要       │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  [1] PowerShell を管理者で起動   │
│      quick-fix.ps1 を実行       │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  [2] スクリプト実行             │
│  - 画像ファイル生成             │
│  - app.json 更新                │
│  - キャッシュクリア             │
│  - npm install                  │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  [3] ローカルテスト (Optional)  │
│  npx expo prebuild --platform   │
│  android --clean                │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  [4] EAS Build 実行             │
│  eas build --platform android   │
│  --profile development          │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  ✓ BUILD SUCCESS!               │
│  APK ダウンロード可能           │
└─────────────────────────────────┘
```

---

## 🚀 実行手順（詳細版）

### ステップ 1: PowerShell を開く

1. Windows キーを押す
2. "PowerShell" と入力
3. **"Windows PowerShell"** を右クリック → **"管理者として実行"**
4. "このアプリがデバイスに変更を加えることを許可しますか？" → **"はい"**

### ステップ 2: スクリプトを実行

PowerShell ウィンドウに以下をコピー＆ペーストして実行：

```powershell
cd D:\JS
powershell -ExecutionPolicy Bypass -File ".\quick-fix.ps1"
```

**または、スクリプト内容を直接コピー＆ペースト：**

```powershell
# D:\JS に移動して、以下の内容をすべてコピー＆ペースト
cd D:\JS

# Python で画像を生成
python -c "
from PIL import Image
Image.new('RGB', (1024, 1024), color=(66, 165, 245)).save('assets/adaptive-icon.png')
Image.new('RGB', (1080, 2340), color=(66, 165, 245)).save('assets/splash.png')
Image.new('RGB', (192, 192), color=(66, 165, 245)).save('assets/icon.png')
print('Images created')
"

# npm をリセット
npm cache clean --force
npm install --legacy-peer-deps
```

### ステップ 3: ローカルテスト（オプション）

```powershell
npx expo prebuild --platform android --clean
```

**期待される出力：**
```
✓ Cleared android code
✓ Created native directory
✓ Updated package.json | no changes
✓ Finished prebuild
```

✅ **このステップで成功したら、ステップ 4 に進んで OK**

❌ **エラーが出たら、下のトラブルシューティングを参照**

### ステップ 4: EAS Build で本ビルド

```powershell
eas build --platform android --profile development
```

**処理内容：**
- プロジェクトをアップロード（2～3分）
- クラウドでビルド開始（5～10分待機）
- ビルド完了メッセージを表示

**成功メッセージ例：**
```
✓ Build finished
Download your app: https://expo.dev/accounts/.../builds/...
```

---

## 🆘 トラブルシューティング

### ❌ エラー 1: "adaptive-icon.png が見つからない"

**原因：** 画像ファイルが作成されていない

**解決方法：**

```powershell
cd D:\JS

# 方法 A: Python で作成（推奨）
python -c "
from PIL import Image
import os
os.makedirs('assets', exist_ok=True)
Image.new('RGB', (1024, 1024), color=(66, 165, 245)).save('assets/adaptive-icon.png')
Image.new('RGB', (1080, 2340), color=(66, 165, 245)).save('assets/splash.png')
Image.new('RGB', (192, 192), color=(66, 165, 245)).save('assets/icon.png')
"

# 作成確認
dir assets
```

**方法 B: 手動作成**
- 以下のファイルを作成してアップロード：
  - `adaptive-icon.png` (1024×1024)
  - `splash.png` (1080×2340)
  - `icon.png` (192×192)

### ❌ エラー 2: "Python not found"

**解決方法：**

1. Python をダウンロード：https://www.python.org/downloads/
2. インストール時に **"Add Python to PATH"** にチェック
3. PowerShell を再起動
4. 確認：`python --version`
5. Pillow をインストール：`pip install Pillow`

### ❌ エラー 3: "JAVA_HOME is not set"

**このエラーはローカルテストでのみ出現**  
（EAS Build を使う場合は無視してOK）

**ローカルテストが必要な場合の解決方法：**

```powershell
# Java をダウンロード
# https://www.oracle.com/java/technologies/downloads/

# インストール後、以下を実行
[Environment]::SetEnvironmentVariable(
    "JAVA_HOME", 
    "C:\Program Files\Java\jdk-21", 
    "Machine"
)

# PowerShell を再起動して確認
java -version
```

### ❌ エラー 4: "Gradle build failed with unknown error"

**EAS Build のエラー**

**解決方法：**

```powershell
cd D:\JS

# 1. ローカルでキャッシュをすべてクリア
rm -r node_modules -ErrorAction SilentlyContinue
npm cache clean --force

# 2. 再インストール
npm install --legacy-peer-deps

# 3. クリーンビルド
npx expo prebuild --platform android --clean

# 4. 再ビルド
eas build --platform android --profile development
```

### ❌ エラー 5: "npm install が失敗する"

**解決方法：**

```powershell
cd D:\JS

# 1. npm を最新に更新
npm install -g npm@latest

# 2. キャッシュクリア
npm cache clean --force

# 3. 古いロックファイルを削除
rm package-lock.json -ErrorAction SilentlyContinue

# 4. 再インストール（--legacy-peer-deps は重要）
npm install --legacy-peer-deps
```

### ❌ エラー 6: "Build timed out"

**原因：** ネットワークが遅い or プロジェクトが大きい

**解決方法：**

1. インターネット接続を確認
2. 不要ファイルを `.easignore` に追加：

```
node_modules/
.git/
.env
*.log
dist/
build/
```

3. 再実行：`eas build --platform android --profile development`

### ❌ エラー 7: "module not found"

**原因：** 依存関係が足りない

**解決方法：**

```powershell
cd D:\JS

# package.json を確認してプラグインをインストール
npm install expo-build-properties
npm install expo-system-ui

# 再ビルド
eas build --platform android --profile development
```

---

## ✅ チェックリスト（実行前に確認）

### ファイル確認

```powershell
cd D:\JS

# 以下を実行して、すべてが ✓ 出ることを確認
ls -la assets\adaptive-icon.png
ls -la assets\splash.png
ls -la assets\icon.png
ls -la app.json
ls -la package.json
```

### app.json の内容確認

```powershell
# 以下を実行してjSONが正しいか確認
type app.json | ConvertFrom-Json | Out-Host
```

### npm の状態確認

```powershell
npm list expo
npm list eas-cli
node --version
npm --version
```

---

## 📞 よくある質問

### Q: ローカルテストをスキップしても大丈夫？

**A:** はい。EAS Build はクラウドでビルドするので、ローカルテストなしでも動作します。  
ただし、ローカルテストを先にすることで問題を早く発見できます。

### Q: 画像ファイルのサイズはいくつがいい？

**A:** 以下を推奨：
- `adaptive-icon.png`: 1024×1024px（正方形必須）
- `splash.png`: 1080×2340px（16:9 比率）
- `icon.png`: 192×192px

### Q: アイコンとスプラッシュ画面に自分の画像を使いたい

**A:** 以下の手順：
1. PNG 形式で画像を用意（上記のサイズで）
2. `assets/` フォルダに配置
3. スクリプトを再実行

### Q: ビルドにどのくらい時間がかかる？

**A:** 通常 5～15分
- アップロード: 2～3分
- ビルド中: 3～10分
- 総計: 5～15分

### Q: ビルド後の APK はどこから取得？

**A:** ビルド成功メッセージに URL が表示されます：
```
✓ Build finished
Download your app: https://expo.dev/accounts/.../builds/...
```

そこから APK をダウンロード可能

---

## 🎯 最速実行（全コマンド）

急いでいる場合は、このセクション全体をコピー＆ペーストして実行：

```powershell
# 1. プロジェクトディレクトリに移動
cd D:\JS

# 2. 画像を生成
python -c "from PIL import Image; import os; os.makedirs('assets', exist_ok=True); Image.new('RGB', (1024, 1024), color=(66, 165, 245)).save('assets/adaptive-icon.png'); Image.new('RGB', (1080, 2340), color=(66, 165, 245)).save('assets/splash.png'); Image.new('RGB', (192, 192), color=(66, 165, 245)).save('assets/icon.png')"

# 3. キャッシュをクリア & 再インストール
npm cache clean --force
npm install --legacy-peer-deps

# 4. ビルド実行（ローカルテストスキップ）
eas build --platform android --profile development
```

完了！

---

## 📚 参考リンク

- **Expo 公式ドキュメント**: https://docs.expo.dev/
- **EAS Build ガイド**: https://docs.expo.dev/eas/build/
- **スプラッシュスクリーン設定**: https://docs.expo.dev/develop/user-interface/splash-screen/
- **アプリアイコン設定**: https://docs.expo.dev/develop/user-interface/app-icons/
- **Adaptive Icon ドキュメント**: https://developer.android.com/guide/practices/ui_guidelines/image_buttons

---

## ⚠️ 最後の注意

- ✅ スクリプトは D:\JS で実行してください
- ✅ PowerShell を**管理者で実行**してください
- ✅ インターネット接続が必要です
- ✅ ビルド中はコマンドを中断しないでください
- ✅ エラーが出たら、エラーメッセージ全体を読んでください

---

**準備完了！ビルドを開始して、成功を祈ります！ 🚀**
