# Expo Android Build - Complete Fix Guide

## 🎯 問題の根本原因
- ❌ adaptive-icon.png が見つからない
- ❌ splash.png が見つからない  
- ❌ app.json が画像ファイルを正しく参照していない
- ❌ キャッシュが古い可能性

---

## ✅ 解決手順（実行順序が重要）

### PHASE 1: 最小限の画像ファイルを作成する

**Option A: Pythonで自動生成（推奨）**

PowerShellで以下を実行：

```powershell
# D:\JS に移動
cd D:\JS

# 必要なディレクトリを確認
if (-not (Test-Path "assets")) { mkdir assets }

# Python で画像を生成
python -c "
from PIL import Image
# adaptive-icon.png (1024x1024 - 正方形必須)
Image.new('RGB', (1024, 1024), color=(66, 165, 245)).save('assets/adaptive-icon.png')
# splash.png (1080x2340)
Image.new('RGB', (1080, 2340), color=(66, 165, 245)).save('assets/splash.png')
# icon.png (192x192)
Image.new('RGB', (192, 192), color=(66, 165, 245)).save('assets/icon.png')
print('✓ All images created successfully')
"
```

**Option B: 手動作成（Pythonがない場合）**

- 各画像ファイルを `assets/` フォルダに配置：
  - `adaptive-icon.png`: 1024×1024px（正方形）
  - `splash.png`: 1080×2340px
  - `icon.png`: 192×192px
  
最低限のカラーファイルでOK（背景色は一色でも動作）

---

### PHASE 2: app.json を正しく設定する

以下の設定が `app.json` に含まれていることを確認：

```json
{
  "expo": {
    "name": "my-new-quiz",
    "slug": "my-new-quiz",
    "version": "1.0.0",
    "icon": "./assets/icon.png",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#42A5F5"
    },
    "android": {
      "package": "com.example.mynewquiz",
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#42A5F5"
      }
    },
    "plugins": [
      [
        "expo-build-properties",
        {
          "android": {
            "usesCleartextTraffic": true
          }
        }
      ]
    ]
  }
}
```

**重要チェックポイント：**
- ✅ `icon` パスが存在する
- ✅ `splash.image` パスが存在する
- ✅ `adaptiveIcon.foregroundImage` パスが存在する
- ✅ `android.package` が設定されている（例：`com.example.mynewquiz`）

---

### PHASE 3: キャッシュをクリアして再インストール

```powershell
cd D:\JS

# 1. 古いビルド成果物を削除
if (Test-Path "android") { 
    Remove-Item "android" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "✓ Removed old android directory"
}

# 2. Node modules キャッシュをクリア
if (Test-Path "node_modules\.cache") { 
    Remove-Item "node_modules\.cache" -Recurse -Force -ErrorAction SilentlyContinue
}

# 3. 依存関係を再インストール
npm install
```

---

### PHASE 4: ローカル prebuild でテスト

```powershell
cd D:\JS

# クリーンビルドで prebuild を実行
npx expo prebuild --platform android --clean
```

**期待される出力：**
```
✓ Cleared android code
✓ Created native directory
✓ Updated package.json | no changes
✓ Finished prebuild
```

⚠️ もしここで **JAVA_HOME エラー** が出たら：
```powershell
# Java をダウンロード：https://www.oracle.com/java/technologies/downloads/
# インストール後、以下を実行：
$env:JAVA_HOME = "C:\Program Files\Java\jdk-<version>"
```

---

### PHASE 5: EAS Build で本ビルド

```powershell
cd D:\JS

# EAS Build を実行
eas build --platform android --profile development
```

**期待される流れ：**
1. 環境を確認中...
2. プロジェクトをアップロード中...
3. ビルド開始...
4. 5～10分待機
5. ✓ ビルド成功！

---

## 🆘 トラブルシューティング

### エラー: "ENOENT: no such file or directory, open 'adaptive-icon.png'"
**解決：** 
- `assets/adaptive-icon.png` ファイルが存在することを確認
- ファイルサイズが 0 バイトでないか確認
- ファイル名のスペルを確認

### エラー: "Gradle build failed with unknown error"
**解決：**
1. ローカルで `npx expo prebuild --clean` を実行
2. `npm install` を再実行
3. `node_modules` をすべて削除して再インストール：
   ```powershell
   rm -r node_modules
   npm install
   ```

### エラー: "JAVA_HOME is not set"
**解決：** 
ローカルテストが必要な場合のみ対応（EAS Buildなら不要）
```powershell
# Java をインストール後：
[Environment]::SetEnvironmentVariable("JAVA_HOME", "C:\Program Files\Java\jdk-<version>", "Machine")
```

### エラー: "Build timed out"
**解決：**
- プロジェクトサイズを削減（`.easignore` に不要ファイルを追加）
- キャッシュをクリア
- しばらく待ってから再試行

---

## 📋 最終チェックリスト

実行前に確認：

- [ ] `D:\JS\assets\adaptive-icon.png` が存在（1024×1024）
- [ ] `D:\JS\assets\splash.png` が存在（1080×2340）
- [ ] `D:\JS\assets\icon.png` が存在（192×192）
- [ ] `app.json` が正しく設定されている
- [ ] `npm install` が成功している
- [ ] ローカル prebuild が成功している

---

## 🚀 最速実行コマンド（全てコピペで実行）

```powershell
# 1. ディレクトリ移動
cd D:\JS

# 2. 画像生成（Pythonあり）
python -c "from PIL import Image; Image.new('RGB', (1024, 1024), color=(66, 165, 245)).save('assets/adaptive-icon.png'); Image.new('RGB', (1080, 2340), color=(66, 165, 245)).save('assets/splash.png'); Image.new('RGB', (192, 192), color=(66, 165, 245)).save('assets/icon.png'); print('Done')"

# 3. キャッシュクリア & 再インストール
rm -r node_modules -ErrorAction SilentlyContinue; npm install

# 4. ローカルテスト
npx expo prebuild --platform android --clean

# 5. ビルド実行
eas build --platform android --profile development
```

---

## 📞 さらに詳しい情報

- Expo ドキュメント: https://docs.expo.dev/
- EAS Build ガイド: https://docs.expo.dev/eas/build/
- 画像要件: https://docs.expo.dev/develop/user-interface/splash-screen/
